let startTime = Date.now()
let elapsedTime = 0
let timerInterval
let laps = []
let lapStartTime = 0

const stopwatchDisplay = document.getElementById('stopwatch')
const startStopButton = document.getElementById('startStop')
const pauseButton = document.getElementById('pause')
const resetButton = document.getElementById('reset')
const lapButton = document.getElementById('lap')
const clearLapsButton = document.getElementById('clearLaps')
const lapTableBody = document.querySelector('#lapTable tbody')
const statsButton = document.getElementById('statsBtn')
const statsDisplay = document.getElementById('stats')

startStopButton.addEventListener('click', startStop)
pauseButton.addEventListener('click', pause)
resetButton.addEventListener('click', reset)
lapButton.addEventListener('click', lap)
clearLapsButton.addEventListener('click', clearLaps)
statsButton.addEventListener('click', showStats)

lapButton.addEventListener('click', lap)

function lap() {
  if (!(elapsedTime == 0)) {
    const currentTime = Date.now()
    const lapTime = currentTime - (lapStartTime || startTime)

    laps.push({
      lap: laps.length + 1,
      startTime: lapStartTime ? lapStartTime - startTime : 0,
      duration: lapTime,
    })

    // startTime: lapStartTime - startTime,

    lapStartTime = currentTime
    updateLaps()
  }
}

function startStop() {
  if (startStopButton.textContent === 'Start') {
    start()
  } else {
    stop()
  }
}

function start() {
  startTime = Date.now() - elapsedTime
  timerInterval = setInterval(updateTime, 10)
  startStopButton.textContent = 'Stop'
}

function stop() {
  clearInterval(timerInterval)
  startStopButton.textContent = 'Start'
}

function pause() {
  stop()
  startStopButton.textContent = 'Resume'
}

function reset() {
  stop()
  elapsedTime = 0
  updateDisplay()
  laps = []

  lapStartTime = 0
  updateLaps()
}

function clearLaps() {
  laps = []
  updateLaps()
  elapsedTime == 0
  lapStartTime = 0
  statsDisplay.innerHTML = ''
}

function showStats() {
  if (laps.length > 0) {
    const lapDurations = laps.map((lap) => lap.duration)
    const slowestLap = formatTime(Math.max(...lapDurations))
    const fastestLap = formatTime(Math.min(...lapDurations))
    const averageLap = formatTime(
      lapDurations.reduce((sum, duration) => sum + duration, 0) /
        lapDurations.length,
    )

    statsDisplay.innerHTML = `
<p>Slowest Lap: ${slowestLap}</p>
<p>Fastest Lap: ${fastestLap}</p>
<p>Average Lap: ${averageLap}</p>
`
  } else {
    statsDisplay.innerHTML = ''
  }
}

function updateTime() {
  elapsedTime = Date.now() - startTime
  updateDisplay()
}

function updateDisplay() {
  stopwatchDisplay.textContent = formatTime(elapsedTime)
}

function updateLaps() {
  lapTableBody.innerHTML = ''

  if (laps.length > 0) {
    laps.forEach((lap) => {
      const row = lapTableBody.insertRow()
      row.insertCell(0).textContent = lap.lap
      row.insertCell(1).textContent = formatTime(lap.startTime)
      row.insertCell(2).textContent = formatTime(lap.duration + lap.startTime)
      row.insertCell(3).textContent = formatTime(lap.duration)
    })
  }
}

function formatTime(milliseconds) {
  const hours = Math.floor(milliseconds / 3600000)
  const minutes = Math.floor((milliseconds % 3600000) / 60000)
  const seconds = Math.floor((milliseconds % 60000) / 1000)
  const centiseconds = Math.floor((milliseconds % 1000) / 10)

  return (
    String(hours).padStart(2, '0') +
    ':' +
    String(minutes).padStart(2, '0') +
    ':' +
    String(seconds).padStart(2, '0') +
    ':' +
    String(centiseconds).padStart(2, '0')
  )
}
